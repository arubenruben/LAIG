/**
• Manages the animation of a game sequence
• Class MyAnimator
• Has:
• Pointer to the orchestrator
• Gets a game sequence
• Methods:
• reset
• start
• update(time)
• Display. Optionally can look at the orchestrator to stop current animation.
 */
class MyAnimator extends CGFobject {
    constructor(scene) {
        super(scene);
        this.scene = scene;
    }
}