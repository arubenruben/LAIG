class MyFlags{


    constructor(){

        //this.play;



    }


}