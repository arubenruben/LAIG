/**
 * MyAnimation
 * @constructor
 * @param scene - Reference to MyScene object
 */
class MyAnimation extends CGFobject {
	constructor(scene) {
		super(scene);
        this.initBuffers();
       
    }
    update(t){
        //altera a posiçao das asas
        this.keyanimation
    }
    
    apply(t){


    }

}

